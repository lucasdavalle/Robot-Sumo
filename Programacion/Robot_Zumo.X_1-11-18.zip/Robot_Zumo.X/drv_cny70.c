#include "mcc_generated_files/mcc.h"
#include "header.h"

void drv_cny70_init()
{
    IOCBF0_SetInterruptHandler(borde_isr);
    IOCBF1_SetInterruptHandler(borde_isr);
    IOCBF2_SetInterruptHandler(borde_isr);
    IOCBF3_SetInterruptHandler(borde_isr);
    bordes.frontleft = 0;
    bordes.frontright = 0;
    bordes.backleft = 0;
    bordes.backright = 0;
}

void borde_isr()
{
    bordes.frontleft = BORDE_FL_GetValue();
    bordes.frontright = BORDE_FR_GetValue();
    bordes.backleft = BORDE_BL_GetValue();
    bordes.backright = BORDE_BR_GetValue();
    borde_detectado();
}