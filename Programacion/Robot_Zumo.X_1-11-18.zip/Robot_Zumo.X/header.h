#ifndef HEADER
#define	HEADER

struct {
    volatile unsigned lcdConectado : 1;
    volatile unsigned debugMode : 2;
} debug_flags;

//debug
char vectorString[20];
void updateLCD();
void debugInit();

//api locomocion

void marcharAdelante();
void marcharAtras();
void girarXgradosizquierda(uint16_t grados);
void girarXgradosderecha(uint16_t grados);
void giroLeveIzquierdaAvanzar(uint16_t tiempo);
void giroLeveDerechaAvanzar(uint16_t tiempo);
void giroLeveIzquierdaRetroceder(uint16_t tiempo);
void giroLeveDerechaRetroceder(uint16_t tiempo);
void detenerse();

//math_routines

char map(char x, char in_min, char in_max, char out_min, char out_max);
uint8_t findClosest(uint8_t* arr, uint8_t n, uint8_t target);
uint8_t getClosest(uint8_t val1, uint8_t val2, uint8_t target);

//drv_motores.c

#define PWMMOT_resolution 199

void motorIz_set(char a); //0 parado, 1 Adelante, 2 Atras
void motorDe_set(char a); //0 parado, 1 Adelante, 2 Atras
void setPwmIz(char pwm);
void setPwmDe(char pwm);

//drv_cny70.c
//api_detectorDeBordes.c

void drv_cny70_init();
void borde_isr();

struct {
    volatile unsigned frontleft : 1;
    volatile unsigned frontright : 1;
    volatile unsigned backleft : 1;
    volatile unsigned backright : 1;
} bordes;

void borde_detectado();



//logica

struct {
    uint8_t distancia;
    uint8_t lado;
} posInicio;

void detectarPosInicio();


//EDITABLE:

#define dist_tacticas_back_size 1
#define dist_tacticas_front_size 2
#define dist_tacticas_left_size 1
#define dist_tacticas_right_size 1

uint8_t dist_tacticas_back[dist_tacticas_back_size];
uint8_t dist_tacticas_front[dist_tacticas_front_size];
uint8_t dist_tacticas_left[dist_tacticas_left_size];
uint8_t dist_tacticas_right[dist_tacticas_right_size];

void tacticas_init();
void elegirTactica(uint8_t lado, uint8_t distancia);

//definicion de tacticas

//tactica 1: ejecutable en lado izquierdo
#define tactica_left_1_id 0
#define tactica_left_1_dist 35
void tactica_left_1();

//tactica 2: ejecutable en lado derecho
#define tactica_right_1_id 0
#define tactica_right_1_dist 35
void tactica_right_1();

//tactica 3: ejecutable en lado frente
#define tactica_front_1_id 0
#define tactica_front_1_dist 80
void tactica_front_1();

//tactica 4: ejecutable en lado frente
#define tactica_front_2_id 1
#define tactica_front_2_dist 30
void tactica_front_2();

//tactica 5: ejecutbale en lado atras
#define tactica_back_1_id 0
#define tactica_back_1_dist 30
void tactica_back_1();

uint8_t tactica;

void tactica_ejecutar(void);

void tactica_elegir(void (* tactica_funcion)(void));

extern void (*tactica_elegida)(void);

void tactica_default(void);

#endif	/* HEADER */