#include "mcc_generated_files/mcc.h"
#include "header.h"
#include "usonic_header.h"

void (*tactica_elegida)(void);

void tacticas_init()
{
    dist_tacticas_left[tactica_left_1_id] = tactica_left_1_dist;

    dist_tacticas_right[tactica_right_1_id] = tactica_right_1_dist;

    dist_tacticas_front[tactica_front_1_id] = tactica_front_1_dist;
    dist_tacticas_front[tactica_front_2_id] = tactica_front_2_dist;

    dist_tacticas_back[tactica_back_1_id] = tactica_back_1_dist;
    
    tactica_elegir(tactica_default);
}

void elegirTactica(uint8_t lado, uint8_t distancia)
{
    uint8_t certeza;
    switch (lado)
    {
        case 0: //back
            certeza = findClosest(dist_tacticas_back, dist_tacticas_back_size, distancia);
            switch (certeza)
            {
                case tactica_back_1_id:
                    tactica_elegir(tactica_back_1);
                    tactica = 1;
                    break;
            }
            break;
        case 1: //front
            certeza = findClosest(dist_tacticas_front, dist_tacticas_front_size, distancia);
            switch (certeza)
            {
                case tactica_front_1_id:
                    tactica_elegir(tactica_front_1);
                    tactica = 2;
                    break;
                case tactica_front_2_id:
                    tactica_elegir(tactica_front_2);
                    tactica = 3;
                    break;
            }
            break;
        case 2: //left
            certeza = findClosest(dist_tacticas_left, dist_tacticas_left_size, distancia);
            switch (certeza)
            {
                case tactica_left_1_id:
                    tactica_elegir(tactica_left_1);
                    tactica = 4;
                    break;
            }
            break;
        case 3: //right
            certeza = findClosest(dist_tacticas_right, dist_tacticas_right_size, distancia);
            switch (certeza)
            {
                case tactica_right_1_id:
                    tactica_elegir(tactica_right_1);
                    tactica = 5;
                    break;
            }
            break;
    }
}

void tactica_default(void){
    
}

void tactica_left_1()
{
    giroLeveIzquierdaRetroceder(3000);
}

void tactica_right_1()
{
    giroLeveDerechaRetroceder(3000);
}

void tactica_front_1()
{
    
}

void tactica_front_2()
{
    
}

void tactica_back_1()
{
    
}


void tactica_ejecutar(void)
{
    // Add your custom callback code here

    if(tactica_elegida)
    {
        tactica_elegida();
    }
}

void tactica_elegir(void (* tactica_funcion)(void)){
    tactica_elegida = tactica_funcion;
}