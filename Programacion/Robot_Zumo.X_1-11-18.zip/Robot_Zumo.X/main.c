#include "mcc_generated_files/mcc.h"
#include "header.h"
#include "drv_lcd.h"
#include "usonic_header.h"
#include <stdbool.h>
#include <stdlib.h>
#include "mcc_generated_files/drivers/i2c_master.h"
#include "mcc_generated_files/drivers/i2c_types.h"
#include <stdio.h>
#include <math.h>

void main(void)
{
    //Inicializar el sistema
    SYSTEM_Initialize();

    //tacticas_init();
    debugInit();
    usonic_init();
    drv_cny70_init();

    //Habilitar Interrupciones.
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
    INTERRUPT_PeripheralInterruptEnable();

    //esperar a leer los ultrasonicos
    while (usonic.distancia.front == 0 || usonic.distancia.back == 0 || usonic.distancia.left == 0 || usonic.distancia.right == 0);

    detectarPosInicio();
    elegirTactica(posInicio.lado, posInicio.distancia);

    LED_1_SetHigh();
    __delay_ms(1000);
    //ejecutar tactica elegida
    tactica_ejecutar();


    while (1)
    {
        /*buscarOponente();   //PROGRAMA VIEJO
        while (oponenteEnMira())
        {
            __delay_ms(25);
            
            if (!(PORTB & 0x0F))
            {
                marcharAdelante();
            } else
            {
                marcharAtras();
                __delay_ms(3000);
                girarXgradosizquierda(135);
            }
        }*/
        __delay_ms(500);
        LED_2_Toggle();
    }
}

void debugInit()
{
    debug_flags.debugMode = 0;
    if (i2c_open(LCD_I2C_ADDRESS) == I2C_NOERR)
    {
        debug_flags.lcdConectado = 1;
        LCD_init();
        TMR5_SetInterruptHandler(updateLCD);
    } else
    {
        debug_flags.lcdConectado = 0;
        PIE4bits.TMR5IE = 0;
        TMR5_StopTimer();
    }
}

void updateLCD()
{
    //    INTERRUPT_GlobalInterruptLowDisable();
    LED_4_Toggle();
    LCD_setCursor(0, 0);
    if (debug_flags.lcdConectado)
    {
        if (debug_flags.debugMode == 0)
        {
            sprintf(vectorString, "F %3ucm B %3ucm    ", usonic.distancia.front, usonic.distancia.back);
            LCD_print(vectorString);
            sprintf(vectorString, "L %3ucm R %3ucm    ", usonic.distancia.left, usonic.distancia.right);
            LCD_setCursor(0, 1);
            LCD_print(vectorString);
        }
        if (debug_flags.debugMode == 1)
        {
            sprintf(vectorString, "Tactica:%1u       ", tactica);
            LCD_print(vectorString);
            sprintf(vectorString, "%3ucm  lado %u          ", posInicio.distancia, posInicio.lado);
            LCD_setCursor(0, 1);
            LCD_print(vectorString);
        }
    }
    //    INTERRUPT_GlobalInterruptLowEnable();
}