#include "mcc_generated_files/mcc.h"
#include "header.h"

void borde_detectado()
{
    
}