#include "mcc_generated_files/mcc.h"
#include "header.h"

char map(char x, char in_min, char in_max, char out_min, char out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


//uint8_t smallest(uint8_t* values, uint8_t count)
//{
//        uint8_t smallest_value = UINT8_MAX;
//        uint8_t ii = 0;
//        for (; ii < count; ++ii)
//        {
//                if (values[ii] < smallest_value)
//                {
//                        smallest_value = values[ii];
//                }
//        }
//        return smallest_value;
//}


// Returns element closest to target in arr[] 

uint8_t findClosest(uint8_t* arr, uint8_t n, uint8_t target)
{
    // Corner cases 
    if (target <= arr[0])
        //return arr[0];
        return 0;
    if (target >= arr[n - 1])
        //return arr[n - 1];
        return n - 1;

    // Doing binary search
    uint8_t i = 0;
    uint8_t j = n;
    uint8_t mid = 0;
    
    while (i < j)
    {
        mid = (i + j) / 2;

        if (arr[mid] == target)
            //return arr[mid];
            return mid;

        /* If target is less than array element, 
            then search in left */
        if (target < arr[mid])
        {

            // If target is greater than previous 
            // to mid, return closest of two 
            if (mid > 0 && target > arr[mid - 1])
            {
                uint8_t a = getClosest(arr[mid - 1], arr[mid], target);
                //return getClosest(arr[mid - 1], arr[mid], target);
                
                if (a == arr[mid - 1])
                    return mid - 1;
                else
                    return mid;
            }
                

            /* Repeat for left half */
            j = mid;
        }

            // If target is greater than mid 
        else
        {
            if (mid < n - 1 && target < arr[mid + 1])
            {
                uint8_t a = getClosest(arr[mid],arr[mid + 1], target);
                
                if (a == arr[mid])
                    return mid;
                else
                    return mid + 1;
            }
                //return getClosest(arr[mid],arr[mid + 1], target);
            // update i 
            i = mid + 1;
        }
    }

    // Only single element left after search 
    //return arr[mid];
    return mid;
}

// Method to compare which one is the more close. 
// We find the closest by taking the difference 
// between the target and both values. It assumes 
// that val2 is greater than val1 and target lies 
// between these two. 

uint8_t getClosest(uint8_t val1, uint8_t val2, uint8_t target)
{
    if (target - val1 >= val2 - target)
        return val2;
    else
        return val1;
}