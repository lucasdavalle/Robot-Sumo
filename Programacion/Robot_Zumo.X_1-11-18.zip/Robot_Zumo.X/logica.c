#include "mcc_generated_files/mcc.h"
#include "header.h"
#include "usonic_header.h"

void detectarPosInicio()
{
    uint8_t distancias[4];
    distancias[0] = usonic.distancia.back;
    distancias[1] = usonic.distancia.front;
    distancias[2] = usonic.distancia.left;
    distancias[3] = usonic.distancia.right;


    uint8_t smallest_value = UINT8_MAX;
    uint8_t ladoMenor;
    uint8_t i = 0;
    for (; i < 4; ++i)
    {
        if (distancias[i] < smallest_value)
        {
            smallest_value = distancias[i];
            ladoMenor = i;
        }
    }

    posInicio.distancia = smallest_value;
    posInicio.lado = ladoMenor;
}

