#include "mcc_generated_files/mcc.h"
#include "header.h"
#include "drv_lcd.h"
#include <stdio.h>

void marcharAdelante()
{
    motorIz_set(1);
    motorDe_set(1);
}

void marcharAtras()
{
    motorIz_set(2);
    motorDe_set(2);
}

void girarXgradosizquierda(uint16_t grados)
{
    motorIz_set(2);
    motorDe_set(1);
    uint16_t del = grados * 27.194; // 9.79s
    while (del--)
    {
        __delay_ms(1);
    }
    detenerse();
}

void girarXgradosderecha(uint16_t grados)
{
    motorIz_set(1);
    motorDe_set(2);
    uint16_t del = grados * 27.194; // 9.79s x 360
    while (del--)
    {
        __delay_ms(1);
    }
    detenerse();
}

void giroLeveIzquierdaAvanzar(uint16_t tiempo)
{
    setPwmIz(140);
    setPwmDe(199);
    marcharAdelante();
    while (tiempo--)
    {
        __delay_ms(1);
    }
    setPwmIz(199);
    setPwmDe(199);
    detenerse();
}

void giroLeveIzquierdaRetroceder(uint16_t tiempo)
{
    setPwmIz(199);
    setPwmDe(140);
    marcharAtras();
    while (tiempo--)
    {
        __delay_ms(1);
    }
    setPwmIz(199);
    setPwmDe(199);
    detenerse();
}

void giroLeveDerechaAvanzar(uint16_t tiempo)
{
    setPwmIz(199);
    setPwmDe(140);
    marcharAdelante();
    while (tiempo--)
    {
        __delay_ms(1);
    }
    setPwmIz(199);
    setPwmDe(199);
    detenerse();
}

void giroLeveDerechaRetroceder(uint16_t tiempo)
{
    setPwmIz(140);
    setPwmDe(199);
    marcharAtras();
    while (tiempo--)
    {
        __delay_ms(1);
    }
    setPwmIz(199);
    setPwmDe(199);
    detenerse();
}

void detenerse()
{
    motorIz_set(0);
    motorDe_set(0);
}

void setVelocidadMarcha(char velocidad) //0 - 99    0% 100%
{
    setPwmIz(velocidad);
    setPwmDe(velocidad);
}