//#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "drv_qmc5883l.h"
#include "universal_i2c.h"
#include <stdio.h>
#include <math.h>

void XYZ_Init()
{
    UI2C_write2Bytes(QMC5883_ADDR, 0x0B, 0x01);
    //Define Set/Reset period
    XYZ_setMode(Mode_Continuous, ODR_200Hz, RNG_8G, OSR_512);
    /*
    Define
    OSR = 512
    Full Scale Range = 8G(Gauss)
    ODR = 200HZ
    set continuous measurement mode
     */
}

void XYZ_setMode(uint8_t mode, uint8_t odr, uint8_t rng, uint8_t osr)
{
    UI2C_write2Bytes(QMC5883_ADDR, 0x09, mode | odr | rng | osr);
}

void XYZ_softReset()
{
    UI2C_write2Bytes(QMC5883_ADDR, 0x0A, 0x80);
}

float XYZ_azimuth(int *a, int *b) //Insertar Y, X.
{
    float azimuth = atan2((int) *a, (int) *b) * 180.0 / 3.1415;
    return azimuth < 0 ? 360 + azimuth : azimuth;
}

void XYZ_Read(int* x, int* y, int* z)
{
    UI2C_write1Byte(QMC5883_ADDR, 0x00);
    
    unsigned char readBuffer[6];
    i2c_readNBytes(QMC5883_ADDR, readBuffer, 6);
    *x = readBuffer[0] | (readBuffer[1] << 8);
    *y = readBuffer[2] | (readBuffer[3] << 8);
    *z = readBuffer[4] | (readBuffer[5] << 8);
}

float XYZ_ReadTemp()
{
    UI2C_write1Byte(QMC5883_ADDR, 0x07);
    int tempVal = (int)UI2C_read2ByteReg(QMC5883_ADDR, LSB_FIRST);
    return (tempVal / 100.0);
}