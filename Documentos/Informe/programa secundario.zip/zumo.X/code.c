#include <xc.h>
#include "config.h"

#define MOT1_Enable PORTAbits.RA0
#define MOT2_Enable PORTAbits.RA5

#define MOT1_A      PORTAbits.RA1
#define MOT1_B      PORTAbits.RA2
#define MOT2_A      PORTAbits.RA3
#define MOT2_B      PORTAbits.RA4

#define ECHO        PORTBbits.RB0
#define ECHO_TRIS   TRISBbits.TRISB0
#define TRIGGER     PORTBbits.RB2   

void main()
{
    ANSEL = 0;
    ANSELH = 0;
    TRISA = 0;
    PORTA = 0;
    TRISB = 0;
    PORTB = 0;
    TRISC = 0;
    PORTC = 0;

    ECHO_TRIS = 1;

    MOT1_Enable = 1;
    MOT2_Enable = 1;
    
    T1CON = 0x00;

    __delay_ms(5000);
    while (1)
    {
        //PULSO DE TRIGGER DE 10us
        TRIGGER = 1;
        __delay_us(10);
        TRIGGER = 0;
        
        while(ECHO == 0);
        unsigned int tiempo = 0;
        T1CONbits.TMR1ON = 1;
        TMR1H = 0;
        TMR1L = 0;
        while(ECHO == 1);
        T1CONbits.TMR1ON = 0;
        tiempo = (TMR1H << 8) | TMR1L;
        
        unsigned int distancia = tiempo * 0.017 * 1.27;
        
        if (distancia <= 75)
        {
            //avanzar
            MOT1_A = 0;
            MOT1_B = 1;
            MOT2_A = 0;
            MOT2_B = 1;
        }
        else
        {
            //girar a la izquierda
            MOT1_A = 0;
            MOT1_B = 1;
            MOT2_A = 1;
            MOT2_B = 0;
        }
    }
}
